# PII Detection Web Application

A full-stack web application for detecting and visualizing Personally Identifiable Information (PII) in PDF documents.

## Architecture

### Frontend
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS
- **PDF Handling**: PDF.js
- **Key Features**:
  - Drag-and-drop PDF upload
  - Interactive PDF viewer with color-coded bounding boxes
  - PII entity type filtering and inspection
  - Responsive design

### Backend
- **Framework**: FastAPI (Python)
- **Database**: ChromaDB for document storage and retrieval
- **PII Detection**: Pattern-based regex matching with support for:
  - Person names
  - Email addresses
  - Phone numbers
  - Social Security Numbers
  - Credit card numbers
  - Addresses
  - Dates

## Getting Started

### Prerequisites
- Node.js (v18+)
- Python (v3.8+)
- npm or yarn

### Frontend Setup

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

The frontend will run on `http://localhost:5173`

### Backend Setup

1. Navigate to the backend directory:
```bash
cd backend
```

2. Install Python dependencies:
```bash
pip install -r requirements.txt
```

3. Start the FastAPI server:
```bash
python main.py
```

The backend API will run on `http://localhost:8000`

## Usage

1. Start both the frontend and backend servers
2. Open the application in your browser
3. Upload a PDF document by dragging and dropping or clicking to select
4. Wait for the PII detection to complete
5. View the document with highlighted PII entities
6. Click on entity types in the sidebar to filter and inspect specific PII instances

## Color Coding

- **Red (PERSON)**: Person names
- **Blue (EMAIL)**: Email addresses
- **Green (PHONE)**: Phone numbers
- **Orange (SSN)**: Social Security Numbers
- **Purple (ADDRESS)**: Physical addresses
- **Yellow (DATE)**: Date values
- **Crimson (CREDIT_CARD)**: Credit card numbers

## API Endpoints

### POST /detect-pii
Upload a PDF and receive PII detection results.

### GET /documents
Retrieve all stored documents from ChromaDB.

### GET /
Health check endpoint.

## Project Structure

```
.
├── src/
│   ├── components/
│   │   ├── PDFUpload.tsx       # PDF upload component
│   │   └── PDFViewer.tsx       # PDF viewer with bounding boxes
│   ├── App.tsx                 # Main application component
│   └── main.tsx               # Application entry point
├── backend/
│   ├── main.py                # FastAPI server and PII detection
│   ├── requirements.txt       # Python dependencies
│   └── README.md             # Backend documentation
└── README.md                 # This file
```

## Build for Production

```bash
npm run build
```

## Technologies Used

- React 18
- TypeScript
- Tailwind CSS
- PDF.js
- FastAPI
- ChromaDB
- Lucide React (icons)
- Axios

## Future Enhancements

- Integration with LLM-based PII detection (OpenAI, Anthropic)
- Advanced PDF parsing for better bounding box accuracy
- Document comparison and diff views
- Export PII reports
- User authentication and document management
- Batch processing support

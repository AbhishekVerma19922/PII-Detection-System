import { useState } from 'react';
import PDFUpload from './components/PDFUpload';
import PDFViewer from './components/PDFViewer';
import { FileText, AlertCircle } from 'lucide-react';
import axios from 'axios';

interface BoundingBox {
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  entity_type: string;
  text: string;
}

function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [boundingBoxes, setBoundingBoxes] = useState<BoundingBox[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = async (file: File) => {
    setSelectedFile(file);
    setIsProcessing(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('pdf', file);

      const response = await axios.post('http://localhost:8000/detect-pii', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setBoundingBoxes(response.data.bounding_boxes);
    } catch (err) {
      console.error('Error processing PDF:', err);
      setError('Failed to process PDF. Please make sure the Python backend is running.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <FileText className="h-10 w-10 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-800">PII Detection System</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Upload a PDF document to automatically detect and highlight personally identifiable information
          </p>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {!selectedFile ? (
          <div className="max-w-2xl mx-auto">
            <PDFUpload onFileSelect={handleFileSelect} isProcessing={isProcessing} />
          </div>
        ) : (
          <div>
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-blue-600" />
                <span className="font-medium text-gray-700">{selectedFile.name}</span>
              </div>
              <button
                onClick={() => {
                  setSelectedFile(null);
                  setBoundingBoxes([]);
                  setError(null);
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Upload New Document
              </button>
            </div>

            {boundingBoxes.length > 0 ? (
              <PDFViewer pdfFile={selectedFile} boundingBoxes={boundingBoxes} />
            ) : isProcessing ? (
              <div className="bg-white rounded-lg shadow-lg p-12 text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Analyzing document for PII...</p>
              </div>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;

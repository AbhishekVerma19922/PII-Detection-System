import { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface BoundingBox {
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  entity_type: string;
  text: string;
}

interface PDFViewerProps {
  pdfFile: File;
  boundingBoxes: BoundingBox[];
}

const entityColors: { [key: string]: string } = {
  PERSON: 'rgba(255, 99, 71, 0.3)',
  EMAIL: 'rgba(65, 105, 225, 0.3)',
  PHONE: 'rgba(50, 205, 50, 0.3)',
  SSN: 'rgba(255, 165, 0, 0.3)',
  ADDRESS: 'rgba(138, 43, 226, 0.3)',
  DATE: 'rgba(255, 215, 0, 0.3)',
  CREDIT_CARD: 'rgba(220, 20, 60, 0.3)',
  DEFAULT: 'rgba(128, 128, 128, 0.3)',
};

export default function PDFViewer({ pdfFile, boundingBoxes }: PDFViewerProps) {
  const canvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  const [numPages, setNumPages] = useState(0);
  const [selectedEntity, setSelectedEntity] = useState<string | null>(null);

  useEffect(() => {
    const loadPDF = async () => {
      const fileReader = new FileReader();

      fileReader.onload = async function () {
        const typedArray = new Uint8Array(this.result as ArrayBuffer);
        const pdf = await pdfjsLib.getDocument(typedArray).promise;
        setNumPages(pdf.numPages);

        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
          const page = await pdf.getPage(pageNum);
          const viewport = page.getViewport({ scale: 1.5 });
          const canvas = canvasRefs.current[pageNum - 1];

          if (canvas) {
            const context = canvas.getContext('2d');
            canvas.height = viewport.height;
            canvas.width = viewport.width;

            if (context) {
              await page.render({
                canvasContext: context,
                viewport: viewport,
              }).promise;

              const pageBoxes = boundingBoxes.filter(box => box.page === pageNum);
              pageBoxes.forEach(box => {
                context.fillStyle = entityColors[box.entity_type] || entityColors.DEFAULT;
                context.fillRect(
                  box.x * viewport.width,
                  box.y * viewport.height,
                  box.width * viewport.width,
                  box.height * viewport.height
                );
                context.strokeStyle = entityColors[box.entity_type]?.replace('0.3', '0.8') || 'rgba(128, 128, 128, 0.8)';
                context.lineWidth = 2;
                context.strokeRect(
                  box.x * viewport.width,
                  box.y * viewport.height,
                  box.width * viewport.width,
                  box.height * viewport.height
                );
              });
            }
          }
        }
      };

      fileReader.readAsArrayBuffer(pdfFile);
    };

    loadPDF();
  }, [pdfFile, boundingBoxes]);

  const entityTypes = Array.from(new Set(boundingBoxes.map(box => box.entity_type)));

  return (
    <div className="flex gap-6">
      <div className="flex-1 bg-white rounded-lg shadow-lg p-6 overflow-auto max-h-[calc(100vh-200px)]" ref={containerRef}>
        <div className="space-y-8">
          {Array.from({ length: numPages }, (_, i) => (
            <div key={i} className="border border-gray-200 rounded">
              <canvas
                ref={el => (canvasRefs.current[i] = el)}
                className="w-full"
              />
              <div className="bg-gray-50 px-4 py-2 text-sm text-gray-600 text-center">
                Page {i + 1}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="w-64 bg-white rounded-lg shadow-lg p-4">
        <h3 className="font-semibold text-lg mb-4">Detected PII</h3>
        <div className="space-y-2">
          {entityTypes.map(entityType => {
            const count = boundingBoxes.filter(box => box.entity_type === entityType).length;
            const color = entityColors[entityType] || entityColors.DEFAULT;

            return (
              <button
                key={entityType}
                onClick={() => setSelectedEntity(selectedEntity === entityType ? null : entityType)}
                className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                  selectedEntity === entityType ? 'bg-gray-100' : 'hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-4 h-4 rounded"
                    style={{ backgroundColor: color }}
                  />
                  <span className="font-medium text-sm">{entityType}</span>
                  <span className="ml-auto text-xs text-gray-500">{count}</span>
                </div>
              </button>
            );
          })}
        </div>

        {selectedEntity && (
          <div className="mt-4 border-t pt-4">
            <h4 className="font-medium text-sm mb-2">Instances:</h4>
            <div className="space-y-2 max-h-64 overflow-auto">
              {boundingBoxes
                .filter(box => box.entity_type === selectedEntity)
                .map((box, idx) => (
                  <div key={idx} className="text-xs bg-gray-50 p-2 rounded">
                    <div className="font-medium">{box.text}</div>
                    <div className="text-gray-500">Page {box.page}</div>
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

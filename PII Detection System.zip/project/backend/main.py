from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import PyPDF2
import io
import re
from typing import List, Dict
import chromadb
from chromadb.config import Settings
import hashlib
from datetime import datetime
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

chroma_client = chromadb.Client(Settings(
    chroma_db_impl="duckdb+parquet",
    persist_directory="./chroma_db"
))

try:
    collection = chroma_client.get_collection(name="pii_documents")
except:
    collection = chroma_client.create_collection(name="pii_documents")


class PIIDetector:
    def __init__(self):
        self.patterns = {
            'EMAIL': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'PHONE': r'\b(?:\+?1[-.]?)?\(?([0-9]{3})\)?[-.]?([0-9]{3})[-.]?([0-9]{4})\b',
            'SSN': r'\b(?!000|666|9\d{2})([0-8]\d{2}|7([0-6]\d))-(?!00)\d{2}-(?!0000)\d{4}\b',
            'CREDIT_CARD': r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12})\b',
            'DATE': r'\b(?:(?:0?[1-9]|1[0-2])[/-](?:0?[1-9]|[12][0-9]|3[01])[/-](?:19|20)\d{2}|\d{4}[/-](?:0?[1-9]|1[0-2])[/-](?:0?[1-9]|[12][0-9]|3[01]))\b',
            'ADDRESS': r'\b\d+\s+[A-Za-z0-9\s]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Lane|Ln|Drive|Dr|Court|Ct|Circle|Cir)\b',
        }

        self.name_indicators = [
            r'\b(?:Mr|Mrs|Ms|Dr|Prof)\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b',
            r'\b[A-Z][a-z]+\s+[A-Z][a-z]+\b',
        ]

    def detect_pii(self, text: str, page_num: int) -> List[Dict]:
        results = []

        for entity_type, pattern in self.patterns.items():
            matches = re.finditer(pattern, text)
            for match in matches:
                results.append({
                    'page': page_num,
                    'entity_type': entity_type,
                    'text': match.group(),
                    'start': match.start(),
                    'end': match.end(),
                })

        for pattern in self.name_indicators:
            matches = re.finditer(pattern, text)
            for match in matches:
                matched_text = match.group()
                if len(matched_text.split()) >= 2:
                    results.append({
                        'page': page_num,
                        'entity_type': 'PERSON',
                        'text': matched_text,
                        'start': match.start(),
                        'end': match.end(),
                    })

        return results


def extract_text_from_pdf(pdf_bytes: bytes) -> Dict[int, str]:
    pdf_file = io.BytesIO(pdf_bytes)
    pdf_reader = PyPDF2.PdfReader(pdf_file)

    pages_text = {}
    for page_num in range(len(pdf_reader.pages)):
        page = pdf_reader.pages[page_num]
        pages_text[page_num + 1] = page.extract_text()

    return pages_text


def calculate_bounding_boxes(pii_entities: List[Dict], pages_text: Dict[int, str]) -> List[Dict]:
    bounding_boxes = []

    for entity in pii_entities:
        page_num = entity['page']
        page_text = pages_text[page_num]

        lines = page_text.split('\n')
        char_count = 0
        found = False

        for line_idx, line in enumerate(lines):
            if entity['start'] >= char_count and entity['start'] < char_count + len(line):
                col_start = entity['start'] - char_count
                col_end = min(entity['end'] - char_count, len(line))

                page_height_estimate = len(lines)
                line_height = 1.0 / page_height_estimate if page_height_estimate > 0 else 0.05

                y = line_idx * line_height
                x = col_start / max(len(line), 1)
                width = (col_end - col_start) / max(len(line), 1)
                height = line_height

                bounding_boxes.append({
                    'page': page_num,
                    'x': max(0, min(x, 1)),
                    'y': max(0, min(y, 1)),
                    'width': max(0, min(width, 1 - x)),
                    'height': max(0, min(height, 1 - y)),
                    'entity_type': entity['entity_type'],
                    'text': entity['text']
                })
                found = True
                break

            char_count += len(line) + 1

        if not found:
            bounding_boxes.append({
                'page': page_num,
                'x': 0.1,
                'y': 0.1,
                'width': 0.3,
                'height': 0.05,
                'entity_type': entity['entity_type'],
                'text': entity['text']
            })

    return bounding_boxes


@app.post("/detect-pii")
async def detect_pii(pdf: UploadFile = File(...)):
    try:
        pdf_bytes = await pdf.read()

        pages_text = extract_text_from_pdf(pdf_bytes)

        detector = PIIDetector()
        all_pii_entities = []

        for page_num, text in pages_text.items():
            pii_entities = detector.detect_pii(text, page_num)
            all_pii_entities.extend(pii_entities)

        bounding_boxes = calculate_bounding_boxes(all_pii_entities, pages_text)

        doc_hash = hashlib.md5(pdf_bytes).hexdigest()

        full_text = '\n'.join(pages_text.values())

        collection.add(
            documents=[full_text],
            metadatas=[{
                'filename': pdf.filename,
                'upload_date': datetime.now().isoformat(),
                'pii_count': len(all_pii_entities),
                'doc_hash': doc_hash
            }],
            ids=[doc_hash]
        )

        return {
            'status': 'success',
            'bounding_boxes': bounding_boxes,
            'pii_count': len(all_pii_entities),
            'document_id': doc_hash
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/")
async def root():
    return {"message": "PII Detection API is running"}


@app.get("/documents")
async def get_documents():
    try:
        results = collection.get()
        return {
            'status': 'success',
            'documents': results
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

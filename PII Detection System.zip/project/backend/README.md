# PII Detection Backend

Python FastAPI backend for detecting personally identifiable information in PDF documents.

## Features

- PDF text extraction
- Pattern-based PII detection (EMAIL, PHONE, SSN, CREDIT_CARD, ADDRESS, DATE, PERSON)
- Bounding box calculation for visual highlighting
- ChromaDB integration for document storage

## Setup

1. Install Python dependencies:
```bash
pip install -r requirements.txt
```

2. Run the server:
```bash
python main.py
```

The server will start on `http://localhost:8000`

## API Endpoints

### POST /detect-pii
Upload a PDF file and get PII detection results with bounding boxes.

**Request:** multipart/form-data with 'pdf' file

**Response:**
```json
{
  "status": "success",
  "bounding_boxes": [...],
  "pii_count": 10,
  "document_id": "abc123"
}
```

### GET /documents
Retrieve all stored documents from ChromaDB.

### GET /
Health check endpoint.

## PII Entity Types

- **PERSON**: Names with titles or first/last name patterns
- **EMAIL**: Email addresses
- **PHONE**: Phone numbers (various formats)
- **SSN**: Social Security Numbers
- **CREDIT_CARD**: Credit card numbers
- **ADDRESS**: Street addresses
- **DATE**: Date patterns

## Database

Documents are stored in ChromaDB with metadata including:
- Filename
- Upload date
- PII count
- Document hash
